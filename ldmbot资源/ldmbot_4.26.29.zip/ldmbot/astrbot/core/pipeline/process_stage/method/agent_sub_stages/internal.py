"""本地 Agent 模式的 LLM 调用 Stage"""

import asyncio
import base64
from collections.abc import AsyncGenerator
from dataclasses import replace

from astrbot.core import db_helper, logger
from astrbot.core.agent.message import (
    CheckpointData,
    CheckpointMessageSegment,
    Message,
    TextPart,
    dump_messages_with_checkpoints,
)
from astrbot.core.agent.response import AgentStats
from astrbot.core.astr_main_agent import (
    LLM_ERROR_MESSAGE_EXTRA_KEY,
    MainAgentBuildConfig,
    MainAgentBuildResult,
    build_main_agent,
)
from astrbot.core.message.components import File, Image, Record, Reply, Video
from astrbot.core.message.message_event_result import (
    MessageChain,
    MessageEventResult,
    ResultContentType,
)
from astrbot.core.persona_error_reply import (
    extract_persona_custom_error_message_from_event,
)
from astrbot.core.pipeline.stage import Stage
from astrbot.core.platform.astr_message_event import AstrMessageEvent
from astrbot.core.provider.entities import (
    LLMResponse,
    ProviderRequest,
)
from astrbot.core.star.star_handler import EventType
from astrbot.core.utils.active_event_registry import active_event_registry
from astrbot.core.utils.metrics import Metric
from astrbot.core.utils.session_lock import session_lock_manager

from .....astr_agent_run_util import AgentRunner, run_agent, run_live_agent
from ....context import PipelineContext, call_event_hook
from ...follow_up import (
    FollowUpCapture,
    finalize_follow_up_capture,
    get_active_runner,
    prepare_follow_up_capture,
    register_active_runner,
    try_capture_follow_up,
    unregister_active_runner,
)


class InternalAgentSubStage(Stage):
    async def initialize(self, ctx: PipelineContext) -> None:
        self.ctx = ctx
        conf = ctx.astrbot_config
        settings = conf["provider_settings"]
        self.streaming_response: bool = settings["streaming_response"]
        self.unsupported_streaming_strategy: str = settings[
            "unsupported_streaming_strategy"
        ]
        self.max_step: int = settings.get("max_agent_step", 30)
        self.tool_call_timeout: int = settings.get("tool_call_timeout", 60)
        self.tool_schema_mode: str = settings.get("tool_schema_mode", "full")
        if self.tool_schema_mode not in ("skills_like", "full"):
            logger.warning(
                "Unsupported tool_schema_mode: %s, fallback to skills_like",
                self.tool_schema_mode,
            )
            self.tool_schema_mode = "full"
        if isinstance(self.max_step, bool):  # workaround: #2622
            self.max_step = 30
        self.show_tool_use: bool = settings.get("show_tool_use_status", True)
        self.show_tool_call_result: bool = settings.get("show_tool_call_result", False)
        self.buffer_intermediate_messages: bool = settings.get(
            "buffer_intermediate_messages",
            False,
        )
        self.show_reasoning = settings.get("display_reasoning_text", False)
        self.sanitize_context_by_modalities: bool = settings.get(
            "sanitize_context_by_modalities",
            False,
        )
        self.kb_agentic_mode: bool = conf.get("kb_agentic_mode", False)

        file_extract_conf: dict = settings.get("file_extract", {})
        self.file_extract_enabled: bool = file_extract_conf.get("enable", False)
        self.file_extract_prov: str = file_extract_conf.get("provider", "moonshotai")
        self.file_extract_msh_api_key: str = file_extract_conf.get(
            "moonshotai_api_key", ""
        )

        # 上下文管理相关
        self.context_limit_reached_strategy: str = settings.get(
            "context_limit_reached_strategy", "truncate_by_turns"
        )
        self.llm_compress_instruction: str = settings.get(
            "llm_compress_instruction", ""
        )
        self.llm_compress_keep_recent_ratio: float = settings.get(
            "llm_compress_keep_recent_ratio", 0.15
        )
        self.llm_compress_provider_id: str = settings.get(
            "llm_compress_provider_id", ""
        )
        self.max_context_length = settings["max_context_length"]  # int
        self.dequeue_context_length: int = min(
            max(1, settings["dequeue_context_length"]),
            self.max_context_length - 1,
        )
        if self.dequeue_context_length <= 0:
            self.dequeue_context_length = 1
        self.fallback_max_context_tokens: int = settings.get(
            "fallback_max_context_tokens", 128000
        )

        self.llm_safety_mode = settings.get("llm_safety_mode", True)
        self.safety_mode_strategy = settings.get(
            "safety_mode_strategy", "system_prompt"
        )

        self.computer_use_runtime = settings.get("computer_use_runtime")
        self.sandbox_cfg = settings.get("sandbox", {})

        # Proactive capability configuration
        proactive_cfg = settings.get("proactive_capability", {})
        self.add_cron_tools = proactive_cfg.get("add_cron_tools", True)

        self.conv_manager = ctx.plugin_manager.context.conversation_manager

        self.main_agent_cfg = MainAgentBuildConfig(
            tool_call_timeout=self.tool_call_timeout,
            tool_schema_mode=self.tool_schema_mode,
            sanitize_context_by_modalities=self.sanitize_context_by_modalities,
            kb_agentic_mode=self.kb_agentic_mode,
            file_extract_enabled=self.file_extract_enabled,
            file_extract_prov=self.file_extract_prov,
            file_extract_msh_api_key=self.file_extract_msh_api_key,
            context_limit_reached_strategy=self.context_limit_reached_strategy,
            llm_compress_instruction=self.llm_compress_instruction,
            llm_compress_keep_recent_ratio=self.llm_compress_keep_recent_ratio,
            llm_compress_provider_id=self.llm_compress_provider_id,
            max_context_length=self.max_context_length,
            dequeue_context_length=self.dequeue_context_length,
            fallback_max_context_tokens=self.fallback_max_context_tokens,
            llm_safety_mode=self.llm_safety_mode,
            safety_mode_strategy=self.safety_mode_strategy,
            computer_use_runtime=self.computer_use_runtime,
            sandbox_cfg=self.sandbox_cfg,
            add_cron_tools=self.add_cron_tools,
            provider_settings=settings,
            subagent_orchestrator=conf.get("subagent_orchestrator", {}),
            timezone=self.ctx.plugin_manager.context.get_config().get("timezone"),
            max_quoted_fallback_images=settings.get("max_quoted_fallback_images", 20),
        )

    async def _send_llm_error_message(
        self, event: AstrMessageEvent, message: object
    ) -> None:
        await event.send(MessageChain().message(str(message)))

    def _get_interrupt_reply_config(self, event: AstrMessageEvent) -> dict:
        conf = self.ctx.plugin_manager.context.get_config(umo=event.unified_msg_origin)
        platform_settings = conf.get("platform_settings", {}) if conf else {}
        interrupt_cfg = platform_settings.get("interrupt_reply", {}) or {}
        return interrupt_cfg if isinstance(interrupt_cfg, dict) else {}

    def _should_interrupt_reply(
        self, event: AstrMessageEvent, interrupt_cfg: dict
    ) -> bool:
        if not interrupt_cfg.get("enable", False):
            return False
        if event.is_private_chat():
            return bool(interrupt_cfg.get("enable_private", True))
        return bool(interrupt_cfg.get("enable_group", True))

    async def _maybe_interrupt_active_reply(
        self,
        event: AstrMessageEvent,
        interrupt_cfg: dict,
    ) -> bool:
        """若同会话已有活跃 LLM 回复，则按配置打断并等待其收尾。

        Returns:
            True 表示发生了打断；False 表示无需打断。
        """
        umo = event.unified_msg_origin
        active_runner = get_active_runner(umo)
        has_other_events = active_event_registry.has_active(umo, exclude=event)
        if active_runner is None and not has_other_events:
            return False

        context_text = ""
        if interrupt_cfg.get("add_to_context", True):
            context_text = str(
                interrupt_cfg.get(
                    "context_text",
                    "[系统提示]用户发来了新消息导致打断了此条回复，"
                    "请联系上下文继续做出回复",
                )
                or "[系统提示]用户发来了新消息导致打断了此条回复，"
                "请联系上下文继续做出回复"
            ).strip()

        # 不向旧任务写 history_note，避免与新请求重复注入
        stopped_count = active_event_registry.request_agent_stop_all(
            umo,
            exclude=event,
            extra_updates={"agent_user_aborted": True},
        )
        logger.info(
            "打断当前回复: umo=%s, 停止请求数=%s, 有活跃runner=%s",
            umo,
            stopped_count,
            active_runner is not None,
        )

        if interrupt_cfg.get("notify_user", True):
            notify_text = str(
                interrupt_cfg.get(
                    "notify_text",
                    "已打断当前回复，开始处理新消息。",
                )
                or "已打断当前回复，开始处理新消息。"
            ).strip()
            if notify_text:
                try:
                    await event.send(MessageChain().message(notify_text))
                except Exception:
                    logger.warning("发送打断提示失败", exc_info=True)

        try:
            wait_timeout = float(interrupt_cfg.get("wait_timeout", 8.0) or 8.0)
        except (TypeError, ValueError):
            wait_timeout = 8.0
        wait_timeout = max(0.0, min(wait_timeout, 60.0))

        idle = await active_event_registry.wait_until_idle(
            umo,
            exclude=event,
            timeout=wait_timeout,
        )
        # 再等一小会儿，尽量让旧任务释放 session lock / 写完历史
        remaining = wait_timeout if not idle else min(1.0, wait_timeout)
        if remaining > 0:
            deadline = asyncio.get_running_loop().time() + remaining
            while get_active_runner(umo) is not None:
                if asyncio.get_running_loop().time() >= deadline:
                    break
                await asyncio.sleep(0.1)

        timed_out = (not idle) or (get_active_runner(umo) is not None)
        if timed_out:
            logger.warning(
                "打断后等待旧任务结束超时: umo=%s, timeout=%s",
                umo,
                wait_timeout,
            )
            # 旧历史可能尚未写入打断提示，临时 system_reminder 兜底
            if context_text:
                event.set_extra("interrupt_reply_context_hint", context_text)
        # 正常收尾时：打断提示已写入旧 assistant 消息历史，不再临时注入以免重复
        return True

    async def process(
        self, event: AstrMessageEvent, provider_wake_prefix: str
    ) -> AsyncGenerator[None, None]:
        follow_up_capture: FollowUpCapture | None = None
        follow_up_consumed_marked = False
        follow_up_activated = False
        typing_requested = False
        try:
            streaming_response = self.streaming_response
            if (enable_streaming := event.get_extra("enable_streaming")) is not None:
                streaming_response = bool(enable_streaming)

            has_provider_request = event.get_extra("provider_request") is not None
            has_valid_message = bool(event.message_str and event.message_str.strip())
            has_media_content = any(
                isinstance(comp, (Image, File, Record, Video))
                for comp in event.message_obj.message
            )
            has_reply = any(
                isinstance(comp, Reply) for comp in event.message_obj.message
            )

            if (
                not has_provider_request
                and not has_valid_message
                and not has_media_content
                and not has_reply
            ):
                logger.debug("skip llm request: empty message and no provider_request")
                return

            logger.debug("ready to request llm provider")
            interrupt_cfg = self._get_interrupt_reply_config(event)
            interrupted = False
            if self._should_interrupt_reply(event, interrupt_cfg):
                interrupted = await self._maybe_interrupt_active_reply(
                    event,
                    interrupt_cfg,
                )

            follow_up_capture = None
            if not interrupted:
                follow_up_capture = try_capture_follow_up(event)
            if follow_up_capture:
                (
                    follow_up_consumed_marked,
                    follow_up_activated,
                ) = await prepare_follow_up_capture(follow_up_capture)
                if follow_up_consumed_marked:
                    logger.info(
                        "Follow-up ticket already consumed, stopping processing. umo=%s, seq=%s",
                        event.unified_msg_origin,
                        follow_up_capture.ticket.seq,
                    )
                    return

            try:
                typing_requested = True
                await event.send_typing()
            except Exception:
                logger.warning("send_typing failed", exc_info=True)
            if await call_event_hook(event, EventType.OnWaitingLLMRequestEvent):
                return

            async with session_lock_manager.acquire_lock(event.unified_msg_origin):
                logger.debug("acquired session lock for llm request")
                agent_runner: AgentRunner | None = None
                runner_registered = False
                try:
                    build_cfg = replace(
                        self.main_agent_cfg,
                        provider_wake_prefix=provider_wake_prefix,
                        streaming_response=streaming_response,
                    )

                    build_result: MainAgentBuildResult | None = await build_main_agent(
                        event=event,
                        plugin_context=self.ctx.plugin_manager.context,
                        config=build_cfg,
                        apply_reset=False,
                    )

                    if build_result is None:
                        if llm_error_message := event.get_extra(
                            LLM_ERROR_MESSAGE_EXTRA_KEY
                        ):
                            await self._send_llm_error_message(
                                event,
                                llm_error_message,
                            )
                        return

                    agent_runner = build_result.agent_runner
                    req = build_result.provider_request
                    provider = build_result.provider
                    reset_coro = build_result.reset_coro

                    api_base = provider.provider_config.get("api_base", "")
                    for host in decoded_blocked:
                        if host in api_base:
                            error_message = (
                                f"LLM 请求失败：Provider API base `{api_base}` "
                                "因安全原因被拦截，请更换可用的 AI 提供商。"
                            )
                            logger.error(error_message)
                            await self._send_llm_error_message(event, error_message)
                            return

                    stream_to_general = (
                        self.unsupported_streaming_strategy == "turn_off"
                        and not event.platform_meta.support_streaming_message
                    )

                    # 仿 system_reminder：作为 extra_user_content_parts 注入，不污染 prompt，且 _no_save 不落库重复
                    context_hint = event.get_extra("interrupt_reply_context_hint")
                    if isinstance(context_hint, str) and context_hint.strip():
                        hint = context_hint.strip()
                        # 若配置已含标签则不再包一层
                        if "<system_reminder>" in hint:
                            reminder = hint
                        else:
                            reminder = f"<system_reminder>{hint}</system_reminder>"
                        req.extra_user_content_parts.append(
                            TextPart(text=reminder).mark_as_temp()
                        )
                        event.set_extra("interrupt_reply_context_hint", None)

                    if await call_event_hook(event, EventType.OnLLMRequestEvent, req):
                        if reset_coro:
                            reset_coro.close()
                        return

                    # apply reset
                    if reset_coro:
                        await reset_coro

                    register_active_runner(event.unified_msg_origin, agent_runner)
                    runner_registered = True
                    action_type = event.get_extra("action_type")

                    event.trace.record(
                        "astr_agent_prepare",
                        system_prompt=req.system_prompt,
                        tools=req.func_tool.names() if req.func_tool else [],
                        stream=streaming_response,
                        chat_provider={
                            "id": provider.provider_config.get("id", ""),
                            "model": provider.get_model(),
                        },
                    )

                    # 检测 Live Mode
                    if action_type == "live":
                        # Live Mode: 使用 run_live_agent
                        logger.info("[Internal Agent] 检测到 Live Mode，启用 TTS 处理")

                        # 获取 TTS Provider
                        tts_provider = (
                            self.ctx.plugin_manager.context.get_using_tts_provider(
                                event.unified_msg_origin
                            )
                        )

                        if not tts_provider:
                            logger.warning(
                                "[Live Mode] TTS Provider 未配置，将使用普通流式模式"
                            )

                        # 使用 run_live_agent，总是使用流式响应
                        event.set_result(
                            MessageEventResult()
                            .set_result_content_type(ResultContentType.STREAMING_RESULT)
                            .set_async_stream(
                                run_live_agent(
                                    agent_runner,
                                    tts_provider,
                                    self.max_step,
                                    self.show_tool_use,
                                    self.show_tool_call_result,
                                    show_reasoning=self.show_reasoning,
                                    buffer_intermediate_messages=self.buffer_intermediate_messages,
                                ),
                            ),
                        )
                        yield

                        # 保存历史记录
                        if agent_runner.done() and (
                            not event.is_stopped() or agent_runner.was_aborted()
                        ):
                            await self._save_to_history(
                                event,
                                req,
                                agent_runner.get_final_llm_resp(),
                                agent_runner.run_context.messages,
                                agent_runner.stats,
                                user_aborted=(
                                    agent_runner.was_aborted()
                                    or bool(event.get_extra("agent_stop_requested"))
                                    or bool(event.get_extra("agent_user_aborted"))
                                ),
                                runner_aborted=agent_runner.was_aborted(),
                            )

                    elif streaming_response and not stream_to_general:
                        # 流式响应
                        event.set_result(
                            MessageEventResult()
                            .set_result_content_type(ResultContentType.STREAMING_RESULT)
                            .set_async_stream(
                                run_agent(
                                    agent_runner,
                                    self.max_step,
                                    self.show_tool_use,
                                    self.show_tool_call_result,
                                    show_reasoning=self.show_reasoning,
                                    buffer_intermediate_messages=self.buffer_intermediate_messages,
                                ),
                            ),
                        )
                        yield
                        if agent_runner.done():
                            if final_llm_resp := agent_runner.get_final_llm_resp():
                                if final_llm_resp.completion_text:
                                    chain = (
                                        MessageChain()
                                        .message(final_llm_resp.completion_text)
                                        .chain
                                    )
                                elif final_llm_resp.result_chain:
                                    chain = final_llm_resp.result_chain.chain
                                else:
                                    chain = MessageChain().chain
                                event.set_result(
                                    MessageEventResult(
                                        chain=chain,
                                        result_content_type=ResultContentType.STREAMING_FINISH,
                                    ),
                                )
                    else:
                        async for _ in run_agent(
                            agent_runner,
                            self.max_step,
                            self.show_tool_use,
                            self.show_tool_call_result,
                            stream_to_general,
                            show_reasoning=self.show_reasoning,
                            buffer_intermediate_messages=self.buffer_intermediate_messages,
                        ):
                            yield

                    final_resp = agent_runner.get_final_llm_resp()

                    event.trace.record(
                        "astr_agent_complete",
                        stats=agent_runner.stats.to_dict(),
                        resp=final_resp.completion_text if final_resp else None,
                    )

                    asyncio.create_task(
                        _record_internal_agent_stats(
                            event,
                            req,
                            agent_runner,
                            final_resp,
                        )
                    )

                    # 检查事件是否被停止，如果被停止则不保存历史记录
                    if not event.is_stopped() or agent_runner.was_aborted():
                        await self._save_to_history(
                            event,
                            req,
                            final_resp,
                            agent_runner.run_context.messages,
                            agent_runner.stats,
                            user_aborted=(
                                agent_runner.was_aborted()
                                or bool(event.get_extra("agent_stop_requested"))
                                or bool(event.get_extra("agent_user_aborted"))
                            ),
                            runner_aborted=agent_runner.was_aborted(),
                        )

                    asyncio.create_task(
                        Metric.upload(
                            llm_tick=1,
                            model_name=agent_runner.provider.get_model(),
                            provider_type=agent_runner.provider.meta().type,
                        ),
                    )
                finally:
                    if runner_registered and agent_runner is not None:
                        unregister_active_runner(event.unified_msg_origin, agent_runner)

        except Exception as e:
            logger.error(f"Error occurred while processing agent: {e}")
            custom_error_message = extract_persona_custom_error_message_from_event(
                event
            )
            error_text = custom_error_message or (
                f"Error occurred while processing agent request: {e}"
            )
            await event.send(MessageChain().message(error_text))
        finally:
            if typing_requested:
                try:
                    await event.stop_typing()
                except Exception:
                    logger.warning("stop_typing failed", exc_info=True)
            if follow_up_capture:
                await finalize_follow_up_capture(
                    follow_up_capture,
                    activated=follow_up_activated,
                    consumed_marked=follow_up_consumed_marked,
                )

    def _extract_message_plain(self, content) -> str:
        if content is None:
            return ""
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for part in content:
                text = getattr(part, "text", None)
                if text:
                    parts.append(str(text))
                elif isinstance(part, dict) and part.get("type") == "text":
                    parts.append(str(part.get("text") or ""))
            return "".join(parts)
        return str(content)

    @staticmethod
    def _normalize_plain_for_compare(text: str) -> str:
        """比较已发送文本与完整回复时忽略空白差异。"""
        if not text:
            return ""
        return "".join(str(text).split())

    def _get_delivered_llm_plain(self, event: AstrMessageEvent) -> str:
        delivered = event.get_extra("_delivered_llm_plain_text") or ""
        if not isinstance(delivered, str):
            delivered = ""
        delivered = delivered.strip()
        if not delivered:
            plain = event.get_extra("_delivered_plain_text") or ""
            if isinstance(plain, str) and plain.strip():
                delivered = plain.strip()
        return delivered

    def _is_llm_reply_fully_delivered(
        self,
        event: AstrMessageEvent,
        *,
        runner_aborted: bool = False,
        original_text: str = "",
        delivered_text: str = "",
    ) -> bool:
        """回复是否已完整发给用户。

        用于区分：
        - 真截断：生成中 / 分段发送中被软打断
        - 收尾撞车：2/2 已发完，仅写历史/注销阶段被标 abort
        后者不应再往历史追加打断系统提示。
        """
        if runner_aborted:
            return False
        if event.get_extra("_llm_reply_send_truncated"):
            return False
        if event.get_extra("_llm_reply_send_completed"):
            return True

        original = self._normalize_plain_for_compare(original_text)
        delivered = self._normalize_plain_for_compare(delivered_text)
        if not original or not delivered:
            return False
        # delivered 可能因分段用换行拼接，归一化后应覆盖完整正文
        return delivered == original or original in delivered

    def _apply_interrupt_to_messages(
        self,
        event: AstrMessageEvent,
        messages: list[Message],
        *,
        runner_aborted: bool = False,
    ) -> list[Message]:
        """打断后：历史仅保留已实际发送内容；真截断时才追加打断提示。

        Args:
            event: 被打断的旧事件。
            messages: 待落库的消息列表（会原地修改）。
            runner_aborted: Agent 是否在生成阶段被 abort（流式中断等）。
                True 时若无发送追踪，则信任 runner 已写入的正文；
                False 表示生成已完成、发送阶段被打断，未发出内容不得入历史。
        """
        delivered = self._get_delivered_llm_plain(event)

        interrupt_cfg = self._get_interrupt_reply_config(event)
        note = ""
        if interrupt_cfg.get("add_to_context", True):
            note = str(
                interrupt_cfg.get(
                    "context_text",
                    "用户发送了新消息并打断了当前回复。"
                    "请仅基于已实际发送给用户的内容与新消息继续对话。",
                )
                or ""
            ).strip()

        # 优先最后一条无 tool_calls 的 assistant（最终回复）
        target_idx = None
        for i in range(len(messages) - 1, -1, -1):
            msg = messages[i]
            if msg.role == "assistant" and not msg.tool_calls:
                target_idx = i
                break
        if target_idx is None:
            for i in range(len(messages) - 1, -1, -1):
                if messages[i].role == "assistant":
                    target_idx = i
                    break

        original = ""
        if target_idx is not None:
            original = self._extract_message_plain(messages[target_idx].content).strip()

        fully_delivered = self._is_llm_reply_fully_delivered(
            event,
            runner_aborted=runner_aborted,
            original_text=original,
            delivered_text=delivered,
        )
        if fully_delivered:
            # 已完整发出：保留原回复正文，不写打断提示
            note = ""
            if not delivered and original:
                delivered = original
            logger.info(
                "软打断时回复已完整发出，跳过打断提示落库: umo=%s, delivered_len=%s",
                event.unified_msg_origin,
                len(delivered or original),
            )

        if delivered:
            final_body = delivered if not fully_delivered else (original or delivered)
        elif runner_aborted:
            # runner 已按已产出文本裁剪，保留其内容
            final_body = None  # 表示保留原文
        else:
            # 生成完成但发送阶段打断且无任何已发送段：不写未发出正文
            final_body = ""

        if target_idx is None:
            content = "" if final_body is None else final_body
            if note:
                content = f"{content}\n{note}" if content else note
            if content:
                messages.append(Message(role="assistant", content=content))
            return messages

        msg = messages[target_idx]
        if final_body is None:
            final_body = original

        if note and note not in (final_body or ""):
            final_body = f"{final_body}\n{note}" if final_body else note

        if msg.tool_calls:
            msg.content = final_body if final_body else None
        else:
            if not final_body:
                messages.pop(target_idx)
            else:
                msg.content = final_body
        return messages

    async def _save_to_history(
        self,
        event: AstrMessageEvent,
        req: ProviderRequest,
        llm_response: LLMResponse | None,
        all_messages: list[Message],
        runner_stats: AgentStats | None,
        user_aborted: bool = False,
        runner_aborted: bool = False,
    ) -> None:
        if not req or not req.conversation:
            return

        # /stop 或 Dashboard 强制停止：整轮作废，不写入对话历史
        # 与「新消息软打断」区分：软打断会保留已发送内容并可选写入打断提示
        if event.get_extra("agent_force_stop"):
            logger.info(
                "/stop 强制停止，跳过写入对话历史: umo=%s, runner_aborted=%s",
                event.unified_msg_origin,
                runner_aborted,
            )
            return

        interrupted = bool(
            user_aborted
            or event.get_extra("agent_stop_requested")
            or event.get_extra("agent_user_aborted")
        )

        # 分段/发送已全部完成时：只是收尾撞上软打断，按正常回复落库
        if interrupted and not runner_aborted:
            delivered = self._get_delivered_llm_plain(event)
            completion = ""
            if llm_response is not None:
                completion = (llm_response.completion_text or "").strip()
            if self._is_llm_reply_fully_delivered(
                event,
                runner_aborted=runner_aborted,
                original_text=completion,
                delivered_text=delivered,
            ):
                logger.info(
                    "软打断发生在回复完整发出之后，按正常历史落库: umo=%s",
                    event.unified_msg_origin,
                )
                interrupted = False

        def _collect_messages_to_save() -> list[Message]:
            messages: list[Message] = []
            skipped_initial_system = False
            for message in all_messages:
                if message.role == "system" and not skipped_initial_system:
                    skipped_initial_system = True
                    continue
                if message.role in ["assistant", "user"] and message._no_save:
                    continue
                messages.append(message)
            return messages

        # LLM 失败（无响应 / 非 assistant）时仍尽量保留 checkpoint，便于续写（#9358）
        if not interrupted and (
            llm_response is None or llm_response.role != "assistant"
        ):
            messages_to_save = _collect_messages_to_save()
            checkpoint_id = event.get_extra("llm_checkpoint_id")
            message_to_save = dump_messages_with_checkpoints(messages_to_save)
            if isinstance(checkpoint_id, str) and checkpoint_id:
                message_to_save.append(
                    CheckpointMessageSegment(
                        content=CheckpointData(id=checkpoint_id),
                    ).model_dump()
                )
                await self.conv_manager.update_conversation(
                    event.unified_msg_origin,
                    req.conversation.cid,
                    history=message_to_save,
                    token_usage=None,
                    event=event,
                )
            return

        if llm_response is None:
            llm_response = LLMResponse(role="assistant", completion_text="")

        if (
            not llm_response.completion_text
            and not req.tool_calls_result
            and not interrupted
        ):
            logger.debug("LLM 响应为空，不保存记录。")
            return

        messages_to_save = _collect_messages_to_save()

        if interrupted:
            messages_to_save = self._apply_interrupt_to_messages(
                event,
                messages_to_save,
                runner_aborted=runner_aborted,
            )
            logger.info(
                "打断后按已发送内容裁剪历史: delivered_len=%s, runner_aborted=%s, send_completed=%s",
                len(self._get_delivered_llm_plain(event)),
                runner_aborted,
                bool(event.get_extra("_llm_reply_send_completed")),
            )

        checkpoint_id = event.get_extra("llm_checkpoint_id")
        message_to_save = dump_messages_with_checkpoints(messages_to_save)
        if isinstance(checkpoint_id, str) and checkpoint_id:
            message_to_save.append(
                CheckpointMessageSegment(
                    content=CheckpointData(id=checkpoint_id),
                ).model_dump()
            )

        token_usage = None
        if runner_stats:
            token_usage = llm_response.usage.total if llm_response.usage else None

        await self.conv_manager.update_conversation(
            event.unified_msg_origin,
            req.conversation.cid,
            history=message_to_save,
            token_usage=token_usage,
            event=event,
        )



# we prevent astrbot from connecting to known malicious hosts
# these hosts are base64 encoded
BLOCKED = {"dGZid2h2d3IuY2xvdWQuc2VhbG9zLmlv", "a291cmljaGF0"}
decoded_blocked = [base64.b64decode(b).decode("utf-8") for b in BLOCKED]


def _format_tokens_k(n: int | float | None) -> str:
    """token 数量格式化：<1000 原样，否则按 k（两位小数）。"""
    try:
        value = int(n or 0)
    except (TypeError, ValueError):
        value = 0
    if abs(value) < 1000:
        return str(value)
    return f"{value / 1000:.2f}k"


def _format_seconds(seconds: float | None) -> str:
    try:
        value = float(seconds or 0.0)
    except (TypeError, ValueError):
        value = 0.0
    if value <= 0:
        return "-"
    if value < 10:
        return f"{value:.2f}s"
    return f"{value:.1f}s"


def _agent_status_label(status: str) -> str:
    return {
        "completed": "完成",
        "aborted": "已中断",
        "error": "错误",
    }.get(status, status or "未知")


def _log_internal_agent_usage(
    *,
    provider,
    stats: AgentStats,
    status: str,
) -> None:
    """把本轮 Agent token/耗时用量打成一条中文 INFO 日志（不发到 IM）。"""
    usage = stats.token_usage
    input_other = int(getattr(usage, "input_other", 0) or 0)
    input_cached = int(getattr(usage, "input_cached", 0) or 0)
    output = int(getattr(usage, "output", 0) or 0)
    input_total = input_other + input_cached
    total = input_total + output
    context_tokens = int(getattr(stats, "current_context_tokens", 0) or 0)
    duration = float(getattr(stats, "duration", 0.0) or 0.0)
    ttft = float(getattr(stats, "time_to_first_token", 0.0) or 0.0)

    model = ""
    provider_display = ""
    try:
        model = str(provider.get_model() or "")
    except Exception:
        model = ""
    try:
        if hasattr(provider, "display_provider_id"):
            provider_display = str(provider.display_provider_id() or "")
        else:
            provider_display = str(getattr(provider.meta(), "id", "") or "")
    except Exception:
        provider_display = ""

    # 缓存为 0 时不啰嗦展示
    if input_cached > 0:
        input_part = (
            f"输入 {_format_tokens_k(input_total)}"
            f"（非缓存 {_format_tokens_k(input_other)} / 缓存 {_format_tokens_k(input_cached)}）"
        )
    else:
        input_part = f"输入 {_format_tokens_k(input_total)}"

    logger.info(
        "Agent 用量: %s | 输出 %s | 合计 %s | 上下文 %s | 耗时 %s | 首token %s | 状态 %s | 模型 %s（提供商: %s）",
        input_part,
        _format_tokens_k(output),
        _format_tokens_k(total),
        _format_tokens_k(context_tokens),
        _format_seconds(duration),
        _format_seconds(ttft),
        _agent_status_label(status),
        model or "unknown",
        provider_display or "unknown",
    )


async def _record_internal_agent_stats(
    event: AstrMessageEvent,
    req: ProviderRequest | None,
    agent_runner: AgentRunner | None,
    final_resp: LLMResponse | None,
) -> None:
    """Persist internal agent stats without affecting the user response flow."""
    if agent_runner is None:
        return

    provider = agent_runner.provider
    stats = agent_runner.stats
    if provider is None or stats is None:
        return

    try:
        provider_config = getattr(provider, "provider_config", {}) or {}
        conversation_id = (
            req.conversation.cid
            if req is not None and req.conversation is not None
            else None
        )

        if agent_runner.was_aborted():
            status = "aborted"
        elif final_resp is not None and final_resp.role == "err":
            status = "error"
        else:
            status = "completed"

        # 全平台可见的用量日志；token 按 k 格式化，不发送到 QQ 等 IM
        try:
            _log_internal_agent_usage(
                provider=provider,
                stats=stats,
                status=status,
            )
        except Exception as log_err:
            logger.debug("打印 Agent 用量日志失败: %s", log_err)

        await db_helper.insert_provider_stat(
            umo=event.unified_msg_origin,
            conversation_id=conversation_id,
            provider_id=provider_config.get("id", "") or provider.meta().id,
            provider_model=provider.get_model(),
            status=status,
            stats=stats.to_dict(),
            agent_type="internal",
        )
    except Exception as e:
        logger.warning("Persist provider stats failed: %s", e, exc_info=True)
